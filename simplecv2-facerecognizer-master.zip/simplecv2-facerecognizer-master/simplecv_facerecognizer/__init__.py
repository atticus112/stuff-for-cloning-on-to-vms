__version__ = '0.0.1'

import os
DATA_DIR = os.path.join(os.path.dirname(__file__), 'data')
