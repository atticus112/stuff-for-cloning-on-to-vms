simplecv2-facerecognizer
========================

SimpleCV v2 functionality for facial recognition
